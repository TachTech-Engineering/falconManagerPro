"""
Falcon Utility Library
Common functions for interacting with CrowdStrike Falcon API
"""

import os
import sys
import time
from typing import List, Dict, Optional
from dotenv import load_dotenv
from falconpy import Detects, IOC


class FalconClient:
    """Wrapper for CrowdStrike Falcon API interactions"""
    
    def __init__(self):
        """Initialize Falcon client with credentials from environment"""
        load_dotenv()
        
        self.client_id = os.getenv('FALCON_CLIENT_ID')
        self.client_secret = os.getenv('FALCON_CLIENT_SECRET')
        self.base_url = os.getenv('FALCON_BASE_URL', 'https://api.crowdstrike.com')
        
        if not self.client_id or not self.client_secret:
            print("ERROR: Missing FALCON_CLIENT_ID or FALCON_CLIENT_SECRET in .env file")
            sys.exit(1)
        
        self.detects = Detects(
            client_id=self.client_id,
            client_secret=self.client_secret,
            base_url=self.base_url
        )
        
        self.ioc = IOC(
            client_id=self.client_id,
            client_secret=self.client_secret,
            base_url=self.base_url
        )
    
    def test_connection(self) -> bool:
        """Test API connection and credentials"""
        try:
            response = self.detects.query_detects(limit=1)
            if response['status_code'] == 200:
                print("✓ Successfully connected to CrowdStrike Falcon API")
                return True
            else:
                print(f"✗ Connection failed: {response['body']['errors']}")
                return False
        except Exception as e:
            print(f"✗ Connection error: {str(e)}")
            return False
    
    def query_detections(self, filter_string: str, limit: int = 100, offset: int = 0) -> List[str]:
        """
        Query detection IDs by filter
        
        Args:
            filter_string: FQL filter string
            limit: Maximum number of results (max 10000)
            offset: Starting offset for pagination
            
        Returns:
            List of detection IDs
        """
        try:
            response = self.detects.query_detects(
                filter=filter_string,
                limit=min(limit, 10000),
                offset=offset
            )
            
            if response['status_code'] == 200:
                return response['body']['resources']
            else:
                print(f"Query failed: {response['body'].get('errors', 'Unknown error')}")
                return []
        except Exception as e:
            print(f"Query error: {str(e)}")
            return []
    
    def get_detection_details(self, detection_ids: List[str]) -> Dict:
        """
        Get detailed information for detection IDs
        
        Args:
            detection_ids: List of detection IDs (max 1000)
            
        Returns:
            Detection details
        """
        try:
            response = self.detects.get_detect_summaries(ids=detection_ids[:1000])
            
            if response['status_code'] == 200:
                return response['body']['resources']
            else:
                print(f"Failed to get details: {response['body'].get('errors', 'Unknown error')}")
                return {}
        except Exception as e:
            print(f"Error getting details: {str(e)}")
            return {}
    
    def update_detections(self, detection_ids: List[str], status: str, 
                         comment: Optional[str] = None, assigned_to: Optional[str] = None) -> bool:
        """
        Update detection status in batches
        
        Args:
            detection_ids: List of detection IDs (max 1000 per call)
            status: New status (false_positive, true_positive, ignored, closed, etc.)
            comment: Optional comment
            assigned_to: Optional user to assign to
            
        Returns:
            True if successful
        """
        if len(detection_ids) > 1000:
            print(f"WARNING: Can only update 1000 detections per call. Truncating to first 1000.")
            detection_ids = detection_ids[:1000]
        
        try:
            params = {
                'ids': detection_ids,
                'status': status
            }
            
            if comment:
                params['comment'] = comment
            if assigned_to:
                params['assigned_to_uuid'] = assigned_to
            
            response = self.detects.update_detects_by_ids(**params)
            
            if response['status_code'] == 200:
                return True
            else:
                print(f"Update failed: {response['body'].get('errors', 'Unknown error')}")
                return False
        except Exception as e:
            print(f"Update error: {str(e)}")
            return False
    
    def bulk_update_detections(self, detection_ids: List[str], status: str,
                              comment: Optional[str] = None, batch_size: int = 1000,
                              delay: float = 0.5) -> Dict[str, int]:
        """
        Update detections in batches with rate limiting
        
        Args:
            detection_ids: List of all detection IDs to update
            status: New status
            comment: Optional comment
            batch_size: Number of detections per batch (max 1000)
            delay: Delay between batches in seconds
            
        Returns:
            Dictionary with success and failure counts
        """
        batch_size = min(batch_size, 1000)
        total = len(detection_ids)
        success_count = 0
        failure_count = 0
        
        print(f"Updating {total} detections in batches of {batch_size}...")
        
        for i in range(0, total, batch_size):
            batch = detection_ids[i:i + batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (total + batch_size - 1) // batch_size
            
            print(f"Processing batch {batch_num}/{total_batches} ({len(batch)} detections)...", end=' ')
            
            if self.update_detections(batch, status, comment):
                success_count += len(batch)
                print("✓")
            else:
                failure_count += len(batch)
                print("✗")
            
            if i + batch_size < total:
                time.sleep(delay)
        
        return {
            'total': total,
            'success': success_count,
            'failure': failure_count
        }


def format_detection_summary(detections: List[Dict]) -> None:
    """Pretty print detection summary"""
    if not detections:
        print("No detections found.")
        return
    
    print(f"\nFound {len(detections)} detection(s):\n")
    
    for det in detections:
        print(f"Detection ID: {det.get('detection_id', 'N/A')}")
        print(f"  Status: {det.get('status', 'N/A')}")
        print(f"  Severity: {det.get('max_severity_displayname', 'N/A')}")
        print(f"  Host: {det.get('device', {}).get('hostname', 'N/A')}")
        print(f"  First Seen: {det.get('first_behavior', 'N/A')}")
        
        behaviors = det.get('behaviors', [])
        if behaviors:
            print(f"  Behaviors: {len(behaviors)}")
            for behavior in behaviors[:3]:  # Show first 3
                print(f"    - {behavior.get('tactic', 'N/A')}: {behavior.get('technique', 'N/A')}")
        print()
